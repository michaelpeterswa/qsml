from qsml import token
from qsml import lexer
from qsml import parser
from qsml import error
from qsml import builder
from qsml import handler

load = handler.load
dump = handler.dump
# loads = handler.loads
# dumps = handler.dumps
