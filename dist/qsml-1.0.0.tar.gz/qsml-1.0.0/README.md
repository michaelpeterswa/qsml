# qsml
qsml is a markup language for key value securities (stock name, amount)
> quick securities markup language is a project geared towards listing portfolios for performing data analysis upon
## Installation
```
git clone https://github.com/michaelpeterswa/qsml.git
```
Or download the file manually.
## Release History
* 1.0.0
   * Opened Repository (06.25.2020)
## Meta
Michael Peters - *enter additional contact information here*

Distributed under the ____ license. See ``LICENSE`` for more information.